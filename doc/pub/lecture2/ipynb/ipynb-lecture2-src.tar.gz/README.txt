This IPython notebook lecture2.ipynb does not require any additional
programs.

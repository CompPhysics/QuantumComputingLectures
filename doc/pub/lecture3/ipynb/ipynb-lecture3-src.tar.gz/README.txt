This IPython notebook lecture3.ipynb does not require any additional
programs.
